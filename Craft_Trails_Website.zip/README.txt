# Craft Trails Website

This folder contains the HTML/CSS website created from the Craft Trails E-Commerce Website Proposal.

Pages from the proposal:
- Home -> index.html
- Shop -> shop.html
- Product Details -> product-details.html
- Shopping Cart -> cart.html
- Checkout -> checkout.html
- Confirmation -> confirmation.html
- Contact Us -> contact.html

The shared external stylesheet is style.css and is linked from every HTML page.
The stylesheet uses the proposal's named colors: Sage Green, Cream, Brown Earth, Dark Brown, and Forest Green.

The Shop page contains images and descriptions for all five product categories/products represented in the proposal.
